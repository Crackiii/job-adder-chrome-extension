window.onload = function(){

	switch(location.href){
		case "https://stackoverflow.com/jobs":
		case "https://stackoverflow.com/jobs/":{
			var _so_jobs = $(".-item.-job.-job-item"),
		    _so_jobs_length = _so_jobs.length,
		    _so_jobs_links = [],_so_jobs_head = [],_so_jobs_company = [],_so_jobs_locs = [];

			for(var i = 0; i < _so_jobs_length ; i ++){ 
			    _so_jobs_links.push("https://stackoverflow.com"+$(".-item.-job.-job-item").eq(i).find(".-job-summary .-title.g-row h2 a").attr("href"));
			    _so_jobs_head.push($(".-item.-job.-job-item").eq(i).find(".-job-summary .-title.g-row h2 a").text());
			    _so_jobs_company.push($(".-item.-job.-job-item").eq(i).find(".-job-summary .-company.g-row .-name").text());
			    _so_jobs_locs.push($(".-item.-job.-job-item").eq(i).find(".-job-summary .-company.g-row .-location").text());
			   
			}

			for(var i = 0; i < _so_jobs_length ; i ++){

			     var _aj_found = '<li class="aj-list-sec row"> <div class="col-8 ajls-head"> <a href="'+_so_jobs_links[i]+'">'+_so_jobs_head[i]+'</a> </div><div class="col-4 ajls-save-tog"><span class="ajlsst-wrap"><span class="ajls-save-sec ajls-save"><i class="fa fa-bookmark-o"></i><span class="ajls-labe"> Save</span></span><span class="ajls-save-sec ajls-saved"><i class="fa fa-check"></i><span class="ajls-labe"> Saved</span></span> </span> </div><div class="col-6 ajls-comp"><i class="fa fa-briefcase"></i> <span>'+_so_jobs_company[i]+'</span></div><div class="col-6 ajls-loc"><i class="fa fa-map-marker"></i> <span>'+_so_jobs_locs[i]+'</span></div></li>';

			     var _aj_found_parent = document.getElementsByClassName("jfw-avail-job-wrap")[0];
			      _aj_found_parent.insertAdjacentHTML("afterbegin",_aj_found);


			}
			call();

			break;
		}
		case "https://www.linkedin.com/jobs/":
		case "https://www.linkedin.com/jobs/*":{
			alert("You are in linked in mate ! ");
			break;
		}

		default:{
			$(".jfw-avail-job").hide();
			$(".jfw-no-job").show();
			break
		}
	}

	

	
}





var imgURL = chrome.extension.getURL("Icons/logo.svg"),
    _body = document.getElementsByTagName("body")[0],
    _html='<div class="job-form-wrap"> <div class="jfw-head row"> <div class="col-6 jfw-logo-sec"><img src="'+imgURL+'"></div><div class="col-6 jfw-close-sec"><i class="fa fa-times-circle"></i></div></div><div class="jfw-head-menu row"> <div class="col-2 jfwhm-sec tab-btn"> <i class="fa fa-globe jfwhm-sec-active"></i> <span class="label">Find Job</span> </div><div class="col-2 jfwhm-sec tab-btn"> <i class="fa fa-plus-circle"></i> <span class="label">Add Job</span> </div><div class="col-2 jfwhm-sec tab-btn"> <i class="fa fa-cog"></i> <span class="label">Settings</span> </div><div class="col-2 jfwhm-sec"> <i class="fa fa-thumb-tack"></i> <span class="label">Board</span> </div><div class="col-2 jfwhm-sec"> <i class="fa fa-map"></i> <span class="label">View Map</span> </div><div class="col-2 jfwhm-sec"><a href="https://fiverr-projects.000webhostapp.com"/><i class="fa fa-user"></i>  <span class="label">Get In</span> </a></div></div><div class="jfw-jobs-lists tab-body"> <div class="jfw-no-job">We couldnt find jobs in this specific page. Our automatic job detection system is improving everyday! For now you can add a job through the <b>ADD JOB</b> form manually.</div><div class="jfw-avail-job"> <div class="jfw-avail-job-wrap"> </div></div></div><form method="POST" class="mjob-add tab-body" id="mjob-add"> <div class="jfw-body"> <div class="jfw-body-wrap"> <div class="col-12 mj-error"></div><div class="my-select"> <div class="my-select-wrap"> <div class="my-selected-head"> <span class="mst-text bt-text">Board Type</span> <i class="fa fa-angle-down"></i> </div><div class="my-select-opts"> <li>My First Board</li></div></div></div><div class="my-select"> <div class="my-select-wrap"> <div class="my-selected-head"> <span class="mst-text jt-text">Job Type</span> <i class="fa fa-angle-down"></i> </div><div class="my-select-opts"> <li>Wishlist</li><li>Rejected</li><li>Applied</li><li>Interview</li><li>Offer</li></div></div></div><input type="text" name="mj_cname" placeholder="Company Name"> <input type="text" name="mj_jobtit" placeholder="Job Title"> <input type="text" name="mj_loc" placeholder="Location"> <input type="text" name="mj_url" placeholder="Post URL"> <textarea name="mj_desc" placeholder="Job Description"></textarea> </div></div><div class="form-submit"> <button type="submit" class="cus-btn cus-btn-blue mj-submit">Save Job</button> </div></form> <div class="col-12 mj-added"> <div class="suw-head"> <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"> <circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/> <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/> </svg> <h3>Job Added</h3></div><div class="suw-desc">Your Jobe has been successfully added ! </div><div class="suw-foot"> <button class="cus-btn cus-btn-blue open-mj-add">Go Back</button><a href="" class="check-link">Check out your Dashboard !</a></div></div><div class="jfw-settings tab-body"> <div class="user-email"> <i class="fa fa-envelope"></i> antesoft17@outlook.com</div><div class="user-board"> <a href=""> <i class="fa fa-thumb-tack"></i> Goto User Board</a> </div><div class="user-logout"> <a href=""> <i class="fa fa-user"></i> Logout</a> </div></div></div>';
    _body.insertAdjacentHTML('beforebegin', _html);







$(".my-select-wrap").click(function(ev){
    ev.stopPropagation();
    var _thisParent = $(this), _delay = 0;
    $(_thisParent).find(".my-select-opts").slideToggle(100);
    $(_thisParent).find(".my-select-opts li").toggleClass("display");
    $(_thisParent).find(".my-select-opts li").each(function(){
        $(this).css("transition-delay",_delay+"s ");
        _delay+=0.08;
    })
    $(document).click(function(e) {
        var event = e.target;
        if (event != "my-select-wrap") {
            $(_thisParent).find(".my-select-opts").slideUp(100);
            $(_thisParent).find(".my-select-opts li").removeClass("display");
        }
    })
    $(_thisParent).find(".my-select-opts li").click(function() {
        $(_thisParent).find(".mst-text").text($(this).text());
    })
})

$(".tab-btn").click(function(){
    var _thisParent = $(this), _index = _thisParent.index(),d = document;
    for(var i = 0; i < 3;i++){
        $(".tab-btn").find(".fa").removeClass("jfwhm-sec-active");
        $(".tab-body").hide();
        _thisParent.find(".fa").addClass("jfwhm-sec-active");
        d.getElementsByClassName("tab-body")[_index].style.display="block";
    }
})

var $draggable = $('.job-form-wrap').draggabilly();

//==========================================================================
//============================================== A D D J O B M A N U A L L Y 
//==========================================================================


$("#mjob-add").submit(function(e){
    e.preventDefault();

    let ev = e.target;

    $(".mj-submit").text("Processing...");
    $(".mj-submit").prop('disabled', true);
    
    $.ajax({
        method:"POST",
        url:"https://fiverr-projects.000webhostapp.com/auth.php",
        data:$(ev).serialize()+"&board_type="+$(".bt-text").text()+"&job_type="+$(".jt-text").text() + "&mjob_add=true",
    }).then(function(res){
        

        switch(res.toLowerCase()){
            case "menu-select":{
                $(".mj-error").css({"display":"block"}).show();
                $(".mj-error").text("You must select an option ! ");
                $(".mj-submit").text("Save Job");
                $(".mj-submit").prop('disabled', false);
                break;
            }
            case "empty-box":{
                $(".mj-error").css({"display":"block"}).show();
                $(".mj-error").text("All fields are required !");
                $(".mj-submit").text("Save Job");
                $(".mj-submit").prop('disabled', false);
                break;
            }
            case "great":{
                $("#mjob-add").trigger("reset");
                $(".bt-text").text("Board Type");
                $(".jt-text").text("Job Type");
                $(".mj-error").hide();
                $("#mjob-add").css({"transform":"scale(0)","transition":"all .3s"}).hide(400);
                $(".mj-added").show();
                $(".open-mj-add").click(function(){
                    $(".mj-added").hide();
                    $("#mjob-add").css({"transform":"scale(1)","transition":"all .3s"}).show();
                    $(".mj-submit").text("Save Job");
                    $(".mj-submit").prop('disabled', false);
                })
                break;
            }
        }

    })

})



//==================================================================
//============================================== A D D J O B A U T O
//==================================================================


function call(){
    
$(".ajls-save").click(function(){   
   

  var _headText = $(this).parent().parent().parent().find(".ajls-head a").text(),
      _descText = "---No Description Given---",
      _jobComp = $(this).parent().parent().parent().find(".ajls-comp span").text(),
      _jobLoc = $(this).parent().parent().parent().find(".ajls-loc span").text(),
      _jobUrl = $(this).parent().parent().parent().find(".ajls-head a").attr("href"),
      _thisParent = $(this);
      


  $.ajax({
    method:"GET",
    url:"https://fiverr-projects.000webhostapp.com/auth.php?ajob_add=true",
    data:{
        jobHead:_headText,
        jobDesc:_descText,
        jobComp:_jobComp,
        jobLoca:_jobLoc,
        jobUrl:_jobUrl
    } 
  }).then(function(res){
     

     switch(res.toLowerCase()){
        case "inserted":{
            $(_thisParent).hide();
            $(_thisParent).siblings().show();
            break;
        }
     }

  })
   
})

}

